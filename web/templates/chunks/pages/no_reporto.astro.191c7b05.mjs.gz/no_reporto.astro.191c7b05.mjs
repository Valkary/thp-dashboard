/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { createComponent } from 'solid-js/web';
import { a as fetchNoReportoAyer, T as Table, $ as $$Report } from './asistencia.astro.6a7c3ba4.mjs';
/* empty css                           */import 'solid-js';

const estaciones = await fetchNoReportoAyer();
let data = [];
if (estaciones) {
  const entries = Object.entries(estaciones);
  for (let i = 0; i < entries.length; i++) {
    !entries[i][1] && data.push({
      estacion: entries[i][0].toUpperCase()
    });
  }
}
function NoReportoAyer() {
  return createComponent(Table, {
    titles: ["Estaciones sin reportar"],
    get data() {
      return Object.values(data);
    }
  });
}

__astro_tag_component__(NoReportoAyer, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$NoReporto = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$NoReporto;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Estaciones sin reportar", "reporte": "Estaciones sin reportar desde ayer" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "NoReportoAyer", NoReportoAyer, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/NoReportoAyer", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro";
const $$url = "/reportes/no_reporto";

export { $$NoReporto as default, $$file as file, $$url as url };
