/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent, m as maybeRenderHead } from '../astro.1eb4733b.mjs';
import { createComponent, ssr, ssrHydrationKey, escape } from 'solid-js/web';
import { c as fetchNoReportoAyer, S as Spinner, T as Table, d as fetchRegistroSemanal, e as fetch_structured_trabajadores, $ as $$Report } from './asistencia.astro.5df3596d.mjs';
import { createResource, createSignal, createEffect, Suspense, Show } from 'solid-js';

const _tmpl$$1 = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando informaci\xF3n...</p></div>"],
  _tmpl$2$1 = ["<p", ">Error de carga de informaci\xF3n!</p>"],
  _tmpl$3$1 = ["<div", ">Error</div>"];
function capitalizeEntries(estaciones) {
  let data = [];
  const entries = Object.entries(estaciones);
  for (let i = 0; i < entries.length; i++) {
    !entries[i][1] && data.push({
      estacion: entries[i][0].toUpperCase()
    });
  }
  return data;
}
function NoReportoAyer() {
  const [estaciones] = createResource(fetchNoReportoAyer);
  const [table, setTable] = createSignal([]);
  createEffect(() => {
    if (estaciones.state === "ready") {
      const data = capitalizeEntries(estaciones());
      setTable(data);
    }
  });
  return createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$3$1, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return estaciones.loading;
        },
        get children() {
          return ssr(_tmpl$$1, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      }), createComponent(Show, {
        get when() {
          return estaciones.error;
        },
        get children() {
          return ssr(_tmpl$2$1, ssrHydrationKey());
        }
      }), createComponent(Show, {
        get when() {
          return estaciones.state === "ready";
        },
        get children() {
          return createComponent(Table, {
            titles: ["Estaciones sin reportar"],
            get data() {
              return Object.values(table());
            }
          });
        }
      })];
    }
  });
}

__astro_tag_component__(NoReportoAyer, "@astrojs/solid-js");

const today = /* @__PURE__ */ new Date();
new Date(today.getFullYear(), 0, 1);
const weekday_today = today.getDay();
const last_thursday = /* @__PURE__ */ new Date();
const next_wednesday = /* @__PURE__ */ new Date();
last_thursday.setDate(weekday_today < 4 ? today.getDate() - weekday_today - 3 : today.getDate() - weekday_today + 4);
next_wednesday.setDate(weekday_today < 4 ? today.getDate() - weekday_today + 3 : today.getDate() - weekday_today + 10);
function fillDates(start, finish) {
  let dates = [];
  let i_date = new Date(start.getTime());
  for (let date = i_date; date <= finish; date.setDate(date.getDate() + 1)) {
    const utc_str_arr = date.toUTCString().split(" ");
    dates.push(`${utc_str_arr[1]} ${utc_str_arr[2]}`);
  }
  return dates;
}
const date_dict = {
  0: "J",
  1: "V",
  2: "S",
  3: "D",
  4: "L",
  5: "M",
  6: "m"
};
function create_date_titles_curr_week() {
  const dates = fillDates(last_thursday, next_wednesday);
  let titles = [];
  for (let i = 0; i < dates.length; i++) {
    titles.push(`${date_dict[i]} - ${dates[i].split(" ")[0]}`);
  }
  return titles;
}
function week_table_init(trabajadores, default_val) {
  const table = new Array(trabajadores.length);
  for (let i = 0; i < trabajadores.length; i++) {
    table[i] = {
      id: trabajadores[i].idTrabajador,
      nombres: `${trabajadores[i].Nombres} ${trabajadores[i].APaterno}`.toUpperCase(),
      J: default_val,
      V: default_val,
      S: default_val,
      D: default_val,
      L: default_val,
      M: default_val,
      m: default_val
    };
  }
  return table;
}
function week_table_fill(table, date_strs, events) {
  const diffTime = Math.abs(today.getTime() - last_thursday.getTime());
  const date_diff = Math.ceil(diffTime / (1e3 * 60 * 60 * 24)) + 1;
  const trab_id_dict = {};
  for (let i = 0; i < table.length; i++) {
    trab_id_dict[table[i].id] = i;
  }
  for (const key in events) {
    const values = events[key];
    for (let i = 0; i < values.length; i++) {
      const date = new Date(values[i]).toUTCString().split(" ");
      const date_str = `${date[1]} ${date[2]}`;
      const date_id = date_strs.indexOf(date_str);
      const day_of_week = date_dict[date_id];
      if (day_of_week === void 0 || !trab_id_dict[key])
        continue;
      const table_id = trab_id_dict[key];
      table[table_id][day_of_week] = true;
    }
  }
  for (let i = 0; i < table.length; i++) {
    for (let j = date_diff + 1; j < 7; j++) {
      table[i][date_dict[j]] = null;
    }
  }
}

const _tmpl$ = ["<span", " class=\"", "\">", "</span>"],
  _tmpl$2 = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando informaci\xF3n...</p></div>"],
  _tmpl$3 = ["<div", ">Error</div>"];
function date_cond(key, value) {
  if (Object.values(date_dict).indexOf(key) === -1) return value;
  if (value === null) return [];
  return ssr(_tmpl$, ssrHydrationKey(), `inline-flex w-full h-full font-bold justify-center items-center text-lg ${value ? "bg-green-300" : "bg-red-300"}`, value ? "\u2714\uFE0F" : "\u2716\uFE0F");
}
const col_conditions = {
  J: date_cond,
  V: date_cond,
  S: date_cond,
  D: date_cond,
  L: date_cond,
  M: date_cond,
  m: date_cond
};
const fechas = fillDates(last_thursday, next_wednesday);
function ReporteTrabajadoresSemana() {
  const [registro_semana] = createResource(fetchRegistroSemanal);
  const [trabajadores] = createResource(fetch_structured_trabajadores);
  const [table, setTable] = createSignal(null);
  createEffect(() => {
    if (trabajadores.state === "ready" && registro_semana.state === "ready") {
      const week_table = week_table_init(trabajadores(), false);
      week_table_fill(week_table, fechas, registro_semana());
      setTable(week_table);
    }
  });
  const titles = ["Nombres", ...create_date_titles_curr_week()];
  return createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$3, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return registro_semana.loading || trabajadores.loading;
        },
        get children() {
          return ssr(_tmpl$2, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      }), createComponent(Show, {
        get when() {
          return registro_semana.error || trabajadores.error;
        },
        children: "Error de carga!"
      }), createComponent(Show, {
        get when() {
          return typeof table() !== "undefined" && table() !== null;
        },
        get children() {
          return createComponent(Table, {
            get data() {
              return table();
            },
            titles: titles,
            col_conditions: col_conditions,
            ignore_cols: ["id"]
          });
        }
      })];
    }
  });
}

__astro_tag_component__(ReporteTrabajadoresSemana, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$NoReporto = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$NoReporto;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Estaciones sin reportar", "reporte": "Sin reportar" }, { "default": ($$result2) => renderTemplate`
    ${maybeRenderHead($$result2)}<section class="w-full max-w-[800px] h-screen flex flex-col gap-5 max-h-screen overflow-hidden px-5">
        <h2 class="text-xl font-bold uppercase">Estaciones de trabajo</h2>
        ${renderComponent($$result2, "NoReportoAyer", NoReportoAyer, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/NoReportoAyer", "client:component-export": "default" })}
        <h2 class="text-xl font-bold uppercase">Trabajadores</h2>
        ${renderComponent($$result2, "ReporteTrabajadoresSemana", ReporteTrabajadoresSemana, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ReporteTrabajadoresSemana", "client:component-export": "default" })}
    </section>
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro";
const $$url = "/reportes/no_reporto";

export { $$NoReporto as default, $$file as file, $$url as url };
