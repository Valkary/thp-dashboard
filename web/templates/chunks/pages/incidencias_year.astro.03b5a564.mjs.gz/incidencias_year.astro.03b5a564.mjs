/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { b as fetch_structured_incidencias, T as Table, S as Spinner, $ as $$Report } from './asistencia.astro.542b0fb2.mjs';
import { ssr, ssrHydrationKey, escape, createComponent } from 'solid-js/web';
import { createSignal, createResource, createEffect, For, Suspense, Show } from 'solid-js';

const _tmpl$ = ["<div", " class=\"flex flex-col gap-1 items-center justify-start\">", "</div>"],
  _tmpl$2 = ["<p", ">", "</p>"],
  _tmpl$3 = ["<div", " class=\"flex h-full justify-start items-start\">", "</div>"],
  _tmpl$4 = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando incidencias</p></div>"],
  _tmpl$5 = ["<div", " class=\"w-full max-w-[800px] min-h-screen flex flex-col items-center gap-5 overflow-hidden px-5\"><div class=\"w-full flex items-center justify-end\"><p>Incidencia:</p><select><option value=\"V\">Vacaciones</option><option value=\"B\">Baja</option><option value=\"P\">Permiso</option><option value=\"F\">Falta</option><option value=\"N\">No laborable</option><option value=\"I\">Incapacidad</option></select></div><!--#-->", "<!--/--><!--#-->", "<!--/--></div>"];
function IncidenciasYear() {
  const [incidencia, setIncidencia] = createSignal("V");
  const [table, setTable] = createSignal([]);
  const [incidencias_resource] = createResource(incidencia, fetch_structured_incidencias);
  createEffect(() => {
    console.log(incidencias_resource());
    if (incidencias_resource.state === "ready") {
      const tmp_table = [];
      let fechas = [];
      for (let i = 0; i < incidencias_resource().length; i++) {
        for (let j = 0; j < incidencias_resource()[i].fechas.length; j++) {
          const fecha = incidencias_resource()[i].fechas[j].split(" ");
          fechas.push(`${fecha[1]} ${fecha[2]}`);
        }
        const fechas_elem = ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(For, {
          each: fechas,
          children: fecha => ssr(_tmpl$2, ssrHydrationKey(), escape(fecha))
        })));
        tmp_table.push({
          nombre: ssr(_tmpl$3, ssrHydrationKey(), escape(incidencias_resource()[i].nombre)),
          total: ssr(_tmpl$3, ssrHydrationKey(), escape(incidencias_resource()[i].total)),
          fechas: fechas_elem
        });
        fechas = [];
      }
      setTable(tmp_table);
    }
  });
  return createComponent(Suspense, {
    get children() {
      return ssr(_tmpl$5, ssrHydrationKey(), escape(createComponent(Show, {
        get when() {
          return incidencias_resource.state === "ready";
        },
        get children() {
          return createComponent(Table, {
            titles: ["NOMBRE", "TOTAL", "FECHAS"],
            get data() {
              return table();
            }
          });
        }
      })), escape(createComponent(Show, {
        get when() {
          return incidencias_resource.state === "refreshing" || incidencias_resource.loading;
        },
        get children() {
          return ssr(_tmpl$4, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      })));
    }
  });
}

__astro_tag_component__(IncidenciasYear, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$IncidenciasYear = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$IncidenciasYear;
  const months = {
    0: "ENE",
    5: "JUN",
    6: "JUL",
    7: "DIC"
  };
  const today = /* @__PURE__ */ new Date();
  const [start_month, end_month] = today.getMonth() > 5 ? [0, 5] : [6, 11];
  const report_title = `Incidencias (${months[start_month]} - HOY)`;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Incidencias", "reporte": report_title }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Incidencias", IncidenciasYear, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/IncidenciasYear", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/incidencias_year.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/incidencias_year.astro";
const $$url = "/reportes/incidencias_year";

export { $$IncidenciasYear as default, $$file as file, $$url as url };
