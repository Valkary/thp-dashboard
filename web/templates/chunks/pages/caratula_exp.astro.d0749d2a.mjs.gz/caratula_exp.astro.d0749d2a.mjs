/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { f as fetch_structured_full_trabajadores, S as Spinner, $ as $$Report } from './asistencia.astro.25fb079f.mjs';
import { createComponent, ssr, ssrHydrationKey, escape, ssrAttribute } from 'solid-js/web';
import { createSignal, createResource, createEffect, Suspense, Show, For } from 'solid-js';

const _tmpl$ = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando informaci\xF3n...</p></div>"],
  _tmpl$2 = ["<div", " class=\"w-full flex flex-row flex-wrap my-4 justify-center\"><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">idTrabajador:</h5><p class=\"w-1/3 border border-black rounded-sm bg-gray-200 text-center\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Nombre completo:</h5><p class=\"w-1/3 border border-black rounded-sm bg-gray-200 text-center\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Foto:</h5><img loading=\"lazy\" alt=\"Foto de trabajador\"", "></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">idSexo:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">idSangre:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Fecha nacimiento:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Fecha alta:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Sueldo:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">NSS:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">CURP:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">RFC:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">INE:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Domicilio:</h5><p class=\"w-1/3 border border-black rounded-sm bg-gray-200 text-center\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Celular:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">idBanco:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">N\xFAmero de cuenta:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">CLABE:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Calzado Medida:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Calzado Medida:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Calzado Medida:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Tel\xE9fono del contacto:</h5><p class=\"", "\">", "</p></div><div class=\"w-1/2 flex flex-row justify-start items-center\"><h5 class=\"font-bold tracking-wide w-2/3\">Beneficiario:</h5><p class=\"", "\">", "</p></div></div>"],
  _tmpl$3 = ["<article", " class=\"mx-8\"><div class=\"flex w-full justify-end gap-4\"><!--#-->", "<!--/--><!--#-->", "<!--/--><select", ">", "</select></div><!--#-->", "<!--/--></article>"],
  _tmpl$4 = ["<div", ">Cargando informacion</div>"],
  _tmpl$5 = ["<option", "><!--#-->", "<!--/--> <!--#-->", "<!--/--></option>"];
function Caratula() {
  const [trabajador, setTrabajador] = createSignal();
  const [currTrabajador, setCurrTrabajador] = createSignal();
  const [trabajadores] = createResource(fetch_structured_full_trabajadores);
  createEffect(() => {
    if (trabajador()) {
      setCurrTrabajador(trabajadores()[trabajador()]);
    }
    console.log(currTrabajador());
  });
  return createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$4, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return trabajadores.error;
        },
        get children() {
          return ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      }), createComponent(Show, {
        get when() {
          return trabajadores.error;
        },
        children: "Error"
      }), createComponent(Show, {
        get when() {
          return trabajadores.state === "ready";
        },
        get children() {
          return ssr(_tmpl$3, ssrHydrationKey(), escape(createComponent(Show, {
            get when() {
              return !trabajador();
            },
            children: "Trabajador no seleccionado"
          })), escape(createComponent(Show, {
            get when() {
              return trabajador();
            },
            children: "Trabajador seleccionado:"
          })), ssrAttribute("value", escape(trabajador(), true), false), escape(createComponent(For, {
            get each() {
              return trabajadores();
            },
            children: (trabajador2, id) => ssr(_tmpl$5, ssrHydrationKey() + ssrAttribute("value", escape(id(), true), false), escape(trabajador2.Nombres), escape(trabajador2.APaterno))
          })), escape(createComponent(Show, {
            get when() {
              return trabajador() && currTrabajador();
            },
            get children() {
              return ssr(_tmpl$2, ssrHydrationKey(), escape(currTrabajador().idTrabajador), `${escape(currTrabajador().Nombres)} ${escape(currTrabajador().APaterno)} ${escape(currTrabajador().AMaterno)}`, ssrAttribute("src", escape(currTrabajador().Foto, true), false), `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().idSexo ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().idSexo) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().idSangre ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().idSangre) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().FecNacimiento ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().FecNacimiento) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().FecAlta ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().FecAlta) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().SBC ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().SBC) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Nss ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Nss) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().CURP ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().CURP) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Rfc ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Rfc) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Ife ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Ife) ?? "X", `${escape(currTrabajador().DomCalle)}, ${escape(currTrabajador().DomNumExt)},${currTrabajador().DomNumInt ? escape(currTrabajador().DomNumInt) + "," : ""} ${escape(currTrabajador().DomColonia)}, ${escape(currTrabajador().DomCp)}, ${escape(currTrabajador().DomCiudad)}, ${escape(currTrabajador().DomEstado)}`, `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Cel ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Cel) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().idBanco ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().idBanco) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().CtaNum ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().CtaNum) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().CtaClabe ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().CtaClabe) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().CalzMedida ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().CalzMedida) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().CalzCasquillo ? "bg-gray-200" : "bg-red-400"}`, currTrabajador().CalzCasquillo ? "Si" : "No", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Contacto ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Contacto) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().TelContacto ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().TelContacto) ?? "X", `w-1/3 border border-black rounded-sm bg-gray-200 text-center ${currTrabajador().Beneficiario ? "bg-gray-200" : "bg-red-400"}`, escape(currTrabajador().Beneficiario) ?? "X");
            }
          })));
        }
      })];
    }
  });
}

__astro_tag_component__(Caratula, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$CaratulaExp = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$CaratulaExp;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Car\xE1tula Expediente", "reporte": "Car\xE1tula de Expediente de Trabajador" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Caratula", Caratula, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/Caratula", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/caratula_exp.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/caratula_exp.astro";
const $$url = "/reportes/caratula_exp";

export { $$CaratulaExp as default, $$file as file, $$url as url };
