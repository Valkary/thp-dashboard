/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { a as fetchDerechoDescanso, S as Spinner, T as Table, $ as $$Report } from './asistencia.astro.25fb079f.mjs';
import { createComponent, ssr, ssrHydrationKey, escape } from 'solid-js/web';
import { createResource, Suspense, Show } from 'solid-js';

const _tmpl$ = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando informaci\xF3n...</p></div>"],
  _tmpl$2 = ["<section", " class=\"w-full max-w-[800px] h-screen flex flex-col items-center gap-5 max-h-screen overflow-hidden px-5\"><!--#-->", "<!--/--><!--#-->", "<!--/--></section>"],
  _tmpl$3 = ["<div", ">No data</div>"];
function DerechoDescanso() {
  const [derecho_resource] = createResource(fetchDerechoDescanso);
  return createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$3, ssrHydrationKey());
    },
    get children() {
      return ssr(_tmpl$2, ssrHydrationKey(), escape(createComponent(Show, {
        get when() {
          return derecho_resource.loading;
        },
        get children() {
          return ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      })), escape(createComponent(Show, {
        get when() {
          return derecho_resource.state === "ready";
        },
        get children() {
          return createComponent(Table, {
            titles: ["idTrabajador", "Nombres", "APaterno", "AMaterno"],
            get data() {
              return derecho_resource();
            }
          });
        }
      })));
    }
  });
}

__astro_tag_component__(DerechoDescanso, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$DerechoDescanso = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$DerechoDescanso;
  const months = {
    0: "ENE",
    5: "JUN",
    6: "JUL",
    7: "DIC"
  };
  const today = /* @__PURE__ */ new Date();
  const [start_month, end_month] = today.getMonth() > 5 ? [0, 5] : [6, 11];
  const year = today.getMonth() > 5 ? today.getUTCFullYear() : today.getUTCFullYear() - 1;
  const report_title = `Trabajadores sin faltas (${months[start_month]} - ${months[end_month]} ${year})`;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Derecho a descanso", "reporte": report_title }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "Derecho", DerechoDescanso, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/DerechoDescanso", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/derecho_descanso.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/derecho_descanso.astro";
const $$url = "/reportes/derecho_descanso";

export { $$DerechoDescanso as default, $$file as file, $$url as url };
