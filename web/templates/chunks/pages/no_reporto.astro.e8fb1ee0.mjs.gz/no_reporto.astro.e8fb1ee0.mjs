/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { createComponent, ssr, ssrHydrationKey } from 'solid-js/web';
import { b as fetchNoReportoAyer, T as Table, c as fetchRegistroSemanal, d as fetch_structured_trabajadores, $ as $$Report } from './asistencia.astro.f5522992.mjs';
import { createResource, createSignal, createEffect, Suspense, Show } from 'solid-js';
/* empty css                           */
const estaciones = await fetchNoReportoAyer();
let data = [];
if (estaciones) {
  const entries = Object.entries(estaciones);
  for (let i = 0; i < entries.length; i++) {
    !entries[i][1] && data.push({
      estacion: entries[i][0].toUpperCase()
    });
  }
}
function NoReportoAyer() {
  return createComponent(Table, {
    titles: ["Estaciones sin reportar"],
    get data() {
      return Object.values(data);
    }
  });
}

__astro_tag_component__(NoReportoAyer, "@astrojs/solid-js");

const today = /* @__PURE__ */ new Date();
new Date(today.getFullYear(), 0, 1);
const weekday_today = today.getDay();
const last_thursday = /* @__PURE__ */ new Date();
const next_wednesday = /* @__PURE__ */ new Date();
last_thursday.setDate(weekday_today < 4 ? today.getDate() - weekday_today - 3 : today.getDate() - weekday_today + 4);
next_wednesday.setDate(weekday_today < 4 ? today.getDate() - weekday_today + 3 : today.getDate() - weekday_today + 10);
function fillDates(start, finish) {
  let dates = [];
  let i_date = new Date(start.getTime());
  for (let date = i_date; date <= finish; date.setDate(date.getDate() + 1)) {
    const utc_str_arr = date.toUTCString().split(" ");
    dates.push(`${utc_str_arr[1]} ${utc_str_arr[2]}`);
  }
  return dates;
}
const date_dict = {
  0: "J",
  1: "V",
  2: "S",
  3: "D",
  4: "L",
  5: "M",
  6: "m"
};
function week_table_init(trabajadores, default_val) {
  const table = new Array(trabajadores.length);
  for (let i = 0; i < trabajadores.length; i++) {
    table[i] = {
      id: trabajadores[i].idTrabajador,
      nombres: `${trabajadores[i].Nombres} ${trabajadores[i].APaterno}`.toUpperCase(),
      J: default_val,
      V: default_val,
      S: default_val,
      D: default_val,
      L: default_val,
      M: default_val,
      m: default_val
    };
  }
  return table;
}
function week_table_fill(table, date_strs, events) {
  const trab_id_dict = {};
  for (let i = 0; i < table.length; i++) {
    trab_id_dict[table[i].id] = i;
  }
  for (const key in events) {
    const values = events[key];
    for (let i = 0; i < values.length; i++) {
      const date = new Date(values[i]).toUTCString().split(" ");
      const date_str = `${date[1]} ${date[2]}`;
      const day_of_week = date_dict[date_strs.indexOf(date_str)];
      if (day_of_week === void 0)
        continue;
      table[trab_id_dict[key]][day_of_week] = true;
    }
  }
}

const _tmpl$ = ["<span", " class=\"", "\">", "</span>"],
  _tmpl$2 = ["<div", ">Error</div>"];
function date_cond(key, value) {
  if (Object.values(date_dict).indexOf(key) === -1) return value;
  return ssr(_tmpl$, ssrHydrationKey(), `inline-flex w-full h-full font-bold justify-center items-center text-lg ${value ? "bg-green-300" : "bg-red-300"}`, value ? "\u2714\uFE0F" : "\u2716\uFE0F");
}
const col_conditions = {
  J: date_cond,
  V: date_cond,
  S: date_cond,
  D: date_cond,
  L: date_cond,
  M: date_cond,
  m: date_cond
};
const fechas = fillDates(last_thursday, next_wednesday);
function ReporteTrabajadoresSemana() {
  const [registro_semana] = createResource(fetchRegistroSemanal);
  const [trabajadores] = createResource(fetch_structured_trabajadores);
  const [table, setTable] = createSignal(null);
  createEffect(() => {
    if (trabajadores.state === "ready" && registro_semana.state === "ready") {
      const week_table = week_table_init(trabajadores(), false);
      week_table_fill(week_table, fechas, registro_semana());
      setTable(week_table);
    }
  });
  return createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$2, ssrHydrationKey());
    },
    get children() {
      return createComponent(Show, {
        get when() {
          return typeof table() !== "undefined" && table() !== null;
        },
        get children() {
          return createComponent(Table, {
            get data() {
              return table();
            },
            titles: ["Nombres", "J", "V", "S", "D", "L", "M", "m"],
            col_conditions: col_conditions,
            ignore_cols: ["id"]
          });
        }
      });
    }
  });
}

__astro_tag_component__(ReporteTrabajadoresSemana, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$NoReporto = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$NoReporto;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Estaciones sin reportar", "reporte": "Estaciones/Trabajadores sin reportar" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "NoReportoAyer", NoReportoAyer, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/NoReportoAyer", "client:component-export": "default" })}
    ${renderComponent($$result2, "ReporteTrabajadoresSemana", ReporteTrabajadoresSemana, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ReporteTrabajadoresSemana", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/no_reporto.astro";
const $$url = "/reportes/no_reporto";

export { $$NoReporto as default, $$file as file, $$url as url };
