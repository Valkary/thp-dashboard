/* empty css                           */import { c as createAstro, a as createComponent, r as renderTemplate, f as renderComponent, m as maybeRenderHead } from '../astro.1eb4733b.mjs';
import { $ as $$Report } from './asistencia.astro.7d61580b.mjs';
import 'solid-js/web';
import 'solid-js';

const $$Astro = createAstro("https://thp.dev");
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Sistema de reporteo THP", "reporte": "Menu" }, { "default": ($$result2) => renderTemplate`
	${maybeRenderHead($$result2)}<div class="flex flex-col gap-4">
		<h2 class="text-2xl font-bold">Consultas y reportes:</h2>
		<a class="underline text-blue-500 ml-5" href="/reportes/asistencia">Asistencia semana actual</a>
		<a class="underline text-blue-500 ml-5" href="/reportes/caratula_exp">Carátula de expediente de trabajador</a>
		<a class="underline text-blue-500 ml-5" href="/reportes/produccion_semana">Produccion Semanal</a>
		<a class="underline text-blue-500 ml-5" href="/reportes/no_reporto">Sin reportar</a>
		<a class="underline text-blue-500 ml-5" href="/reportes/derecho_descanso">Trabajadores sin faltas</a>
	</div>
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro";
const $$url = "";

export { $$Index as default, $$file as file, $$url as url };
