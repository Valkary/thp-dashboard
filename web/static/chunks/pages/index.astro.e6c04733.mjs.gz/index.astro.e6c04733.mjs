/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, b as addAttribute, d as renderHead, e as renderSlot, f as renderComponent } from '../astro.0dd08cba.mjs';
import { ssr, ssrHydrationKey, escape, createComponent } from 'solid-js/web';
import { For, createSignal, createResource, createEffect, Suspense, Show } from 'solid-js';

function reestructure_obj(obj) {
  const keys = Object.keys(obj);
  const len = Object.keys(obj[keys[0]]).length;
  let table = Array.from({ length: len }, () => ({}));
  for (let i = 0; i < len; i++) {
    for (let j = 0; j < keys.length; j++) {
      table[i][keys[j]] = Object.values(obj[keys[j]])[i];
    }
  }
  return table;
}

const host = "192.168.100.7:5000";
async function fetch_structured_station_production_data(station) {
  try {
    const data = await (await fetch(`http://${host}/api/produccion/ultima_semana/${station}`)).json();
    return reestructure_obj(data);
  } catch (err) {
    console.error(err);
    return [];
  }
}

const estaciones = ["FORMULADO", "MEZCLADO", "LAMINADO", "VULCANIZADO", "CARDADO"];

const _tmpl$$1 = ["<table", "><thead class=\"bg-white border-b\"><tr>", "</tr></thead><tbody>", "</tbody></table>"],
  _tmpl$2$1 = ["<th", " scope=\"col\" class=\"text-sm font-medium text-gray-900 px-6 text-center\">", "</th>"],
  _tmpl$3$1 = ["<div", ">No data</div>"],
  _tmpl$4 = ["<tr", " class=\"", "\">", "</tr>"],
  _tmpl$5 = ["<td", " class=\"", "\">", "</td>"];
function Table(props) {
  const data_keys = () => Object.keys(props.data[0]);
  return ssr(_tmpl$$1, ssrHydrationKey(), escape(createComponent(For, {
    get each() {
      return props.titles;
    },
    children: title => ssr(_tmpl$2$1, ssrHydrationKey(), escape(title))
  })), escape(createComponent(For, {
    get each() {
      return props.data;
    },
    get fallback() {
      return ssr(_tmpl$3$1, ssrHydrationKey());
    },
    children: (record, index) => ssr(_tmpl$4, ssrHydrationKey(), `${index() % 2 ? "bg-white" : "bg-gray-100"} border-b`, escape(createComponent(For, {
      get each() {
        return data_keys();
      },
      children: (key, count) => ssr(_tmpl$5, ssrHydrationKey(), `border-2 border-black whitespace-nowrap text-sm font-medium text-gray-900 ${count() === 0 ? "font-medium text-left" : "font-light text-center"}`, props.col_conditions && props.col_conditions[key] ? escape(props.col_conditions[key](key, record[key])) : escape(record[key]))
    })))
  })));
}

__astro_tag_component__(Table, "@astrojs/solid-js");

const _tmpl$ = ["<section", "><!--#-->", "<!--/--><em>Seleccionado: <!--#-->", "<!--/--></em><!--#-->", "<!--/--></section>"],
  _tmpl$2 = ["<button", " class=\"px-5 py-2 rounded-md border border-black mx-5\">", "</button>"],
  _tmpl$3 = ["<p", ">Cargando producci\xF3n...</p>"];
function ProduccionEstacion() {
  const [station, setStation] = createSignal();
  const [resources] = createResource(station, fetch_structured_station_production_data);
  createEffect(() => console.log(resources()));
  return ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(For, {
    each: estaciones,
    children: item => ssr(_tmpl$2, ssrHydrationKey(), escape(item))
  })), escape(station()), escape(createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$3, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return (station() === "MEZCLADO" || station() === "FORMULADO" || station() === "VULCANIZADO" || station() === "CARDADO") && resources() !== null;
        },
        get children() {
          return createComponent(Table, {
            titles: ["Fecha", "Nombres", "Formula", "Cargas"],
            get data() {
              return resources();
            }
          });
        }
      }), createComponent(Show, {
        get when() {
          return station() === "LAMINADO" && resources() !== null;
        },
        get children() {
          return createComponent(Table, {
            titles: ["Trabajador", "Laminado", "Fecha"],
            get data() {
              return resources();
            }
          });
        }
      })];
    }
  })));
}

__astro_tag_component__(ProduccionEstacion, "@astrojs/solid-js");

const $$Astro$1 = createAstro("https://thp.dev");
const $$Layout = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title } = Astro2.props;
  return renderTemplate`<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Astro description">
		<meta name="viewport" content="width=device-width">
		<link rel="icon" type="image/svg+xml" href="/favicon.svg">
		<meta name="generator"${addAttribute(Astro2.generator, "content")}>
		<title>${title}</title>
	${renderHead($$result)}</head>
	<body>
		${renderSlot($$result, $$slots["default"])}
	</body></html>`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/layouts/Layout.astro");

const $$Astro = createAstro("https://thp.dev");
const $$Index = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Welcome to Astro." }, { "default": ($$result2) => renderTemplate`
	
	
	${renderComponent($$result2, "ProduccionEstacion", ProduccionEstacion, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ProduccionEstacion", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro";
const $$url = "";

export { $$Index as default, $$file as file, $$url as url };
