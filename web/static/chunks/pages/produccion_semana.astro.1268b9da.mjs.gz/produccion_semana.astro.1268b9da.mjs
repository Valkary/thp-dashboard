/* empty css                                 */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.0dd08cba.mjs';
import { ssr, ssrHydrationKey, escape, createComponent } from 'solid-js/web';
import { createSignal, createResource, For, Suspense, Show } from 'solid-js';
import { b as fetch_structured_station_production_data } from './CaratulaExp.astro.994fb47d.mjs';
import { T as Table, $ as $$Layout } from './index.astro.229e7cad.mjs';
/* empty css                                 *//* empty css                           */
const estaciones = ["FORMULADO", "MEZCLADO", "LAMINADO", "VULCANIZADO", "CARDADO"];

const _tmpl$ = ["<section", "><!--#-->", "<!--/--><em>Seleccionado: <!--#-->", "<!--/--></em><!--#-->", "<!--/--></section>"],
  _tmpl$2 = ["<button", " class=\"px-5 py-2 rounded-md border border-black mx-5\">", "</button>"],
  _tmpl$3 = ["<p", ">Cargando producci\xF3n...</p>"];
function ProduccionEstacion() {
  const [station, setStation] = createSignal();
  const [resources] = createResource(station, fetch_structured_station_production_data);
  return ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(For, {
    each: estaciones,
    children: item => ssr(_tmpl$2, ssrHydrationKey(), escape(item))
  })), escape(station()), escape(createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$3, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return (station() === "MEZCLADO" || station() === "FORMULADO" || station() === "VULCANIZADO" || station() === "CARDADO") && resources() !== null;
        },
        get children() {
          return createComponent(Table, {
            titles: ["Fecha", "Nombres", "Formula", "Cargas"],
            get data() {
              return resources();
            }
          });
        }
      }), createComponent(Show, {
        get when() {
          return station() === "LAMINADO" && resources() !== null;
        },
        get children() {
          return createComponent(Table, {
            titles: ["Trabajador", "Laminado", "Fecha"],
            get data() {
              return resources();
            }
          });
        }
      })];
    }
  })));
}

__astro_tag_component__(ProduccionEstacion, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$ProduccionSemana = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProduccionSemana;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Reporte Semanal" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "ProduccionEstacion", ProduccionEstacion, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ProduccionEstacion", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/produccion_semana.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/produccion_semana.astro";
const $$url = "/produccion_semana";

export { $$ProduccionSemana as default, $$file as file, $$url as url };
