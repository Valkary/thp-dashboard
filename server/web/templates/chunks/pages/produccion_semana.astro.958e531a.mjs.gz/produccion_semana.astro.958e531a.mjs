/* empty css                           */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, f as renderComponent } from '../astro.1eb4733b.mjs';
import { ssr, ssrHydrationKey, escape, createComponent } from 'solid-js/web';
import { createSignal, createResource, For, Suspense, Show } from 'solid-js';
import { e as fetch_structured_station_production_data, S as Spinner, T as Table, $ as $$Report } from './asistencia.astro.25fb079f.mjs';

const estaciones = ["FORMULADO", "MEZCLADO", "LAMINADO", "VULCANIZADO", "CARDADO"];

const _tmpl$ = ["<div", " class=\"flex flex-row items-center gap-4 text-xl font-bold\"><!--#-->", "<!--/--><p>Cargando informaci\xF3n...</p></div>"],
  _tmpl$2 = ["<p", ">Error de carga</p>"],
  _tmpl$3 = ["<section", " class=\"w-full max-w-[800px] h-screen flex flex-col items-center gap-5 max-h-screen overflow-hidden px-5\"><div class=\"flex flex-wrap gap-4 justify-center\">", "</div><!--#-->", "<!--/--></section>"],
  _tmpl$4 = ["<button", " class=\"", "\">", "</button>"],
  _tmpl$5 = ["<p", ">Error</p>"];
function ProduccionEstacion() {
  const [station, setStation] = createSignal();
  const [resources] = createResource(station, fetch_structured_station_production_data);
  return ssr(_tmpl$3, ssrHydrationKey(), escape(createComponent(For, {
    each: estaciones,
    children: item => ssr(_tmpl$4, ssrHydrationKey(), `${station() === item ? "bg-black text-white font-bold" : ""} px-5 py-2 rounded-md border border-black`, escape(item))
  })), escape(createComponent(Suspense, {
    get fallback() {
      return ssr(_tmpl$5, ssrHydrationKey());
    },
    get children() {
      return [createComponent(Show, {
        get when() {
          return resources.loading;
        },
        get children() {
          return ssr(_tmpl$, ssrHydrationKey(), escape(createComponent(Spinner, {
            size: "lg"
          })));
        }
      }), createComponent(Show, {
        get when() {
          return resources.error;
        },
        get children() {
          return ssr(_tmpl$2, ssrHydrationKey());
        }
      }), createComponent(Show, {
        get when() {
          return resources.state === "ready";
        },
        get children() {
          return [createComponent(Show, {
            get when() {
              return (station() === "MEZCLADO" || station() === "FORMULADO" || station() === "CARDADO") && resources() !== null;
            },
            get children() {
              return createComponent(Table, {
                titles: ["FECHA", "NOMBRES", "F\xD3RMULA", "CARGAS"],
                get data() {
                  return resources();
                }
              });
            }
          }), createComponent(Show, {
            get when() {
              return station() === "VULCANIZADO" && resources() !== null;
            },
            get children() {
              return createComponent(Table, {
                titles: ["FECHA", "NOMBRES", "F\xD3RMULA", "CANTIDAD"],
                get data() {
                  return resources();
                }
              });
            }
          }), createComponent(Show, {
            get when() {
              return station() === "LAMINADO" && resources() !== null;
            },
            get children() {
              return createComponent(Table, {
                titles: ["FECHA", "TRABAJADOR"],
                get data() {
                  return resources();
                }
              });
            }
          })];
        }
      })];
    }
  })));
}

__astro_tag_component__(ProduccionEstacion, "@astrojs/solid-js");

const $$Astro = createAstro("https://thp.dev");
const $$ProduccionSemana = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProduccionSemana;
  return renderTemplate`${renderComponent($$result, "Report", $$Report, { "title": "Reporte Semanal", "reporte": "Producci\xF3n semanal" }, { "default": ($$result2) => renderTemplate`
    ${renderComponent($$result2, "ProduccionEstacion", ProduccionEstacion, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ProduccionEstacion", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/produccion_semana.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/reportes/produccion_semana.astro";
const $$url = "/reportes/produccion_semana";

export { $$ProduccionSemana as default, $$file as file, $$url as url };
