/* empty css                                 */import { _ as __astro_tag_component__, c as createAstro, a as createComponent$1, r as renderTemplate, b as addAttribute, d as renderHead, e as renderSlot, f as renderComponent } from '../astro.0dd08cba.mjs';
import { ssr, ssrHydrationKey, escape, createComponent } from 'solid-js/web';
import { For, createSignal, createResource, createEffect, Switch, Match } from 'solid-js';
import { f as fetchTrabajadores, a as fetchIncidencias, r as reestructure_obj, s as sort_obj_array } from './CaratulaExp.astro.994fb47d.mjs';
/* empty css                           */
const _tmpl$$1 = ["<table", "><thead class=\"bg-white border-b\"><tr>", "</tr></thead><tbody>", "</tbody></table>"],
  _tmpl$2$1 = ["<th", " scope=\"col\" class=\"text-sm font-medium text-gray-900 px-6 text-center\">", "</th>"],
  _tmpl$3$1 = ["<div", ">No data</div>"],
  _tmpl$4 = ["<tr", " class=\"", "\">", "</tr>"],
  _tmpl$5 = ["<td", " class=\"", "\">", "</td>"];
function Table(props) {
  const data_keys = () => Object.keys(props.data[0]);
  return ssr(_tmpl$$1, ssrHydrationKey(), escape(createComponent(For, {
    get each() {
      return props.titles;
    },
    children: title => ssr(_tmpl$2$1, ssrHydrationKey(), escape(title))
  })), escape(createComponent(For, {
    get each() {
      return props.data;
    },
    get fallback() {
      return ssr(_tmpl$3$1, ssrHydrationKey());
    },
    children: (record, index) => ssr(_tmpl$4, ssrHydrationKey(), `${index() % 2 ? "bg-white" : "bg-gray-100"} border-b`, escape(createComponent(For, {
      get each() {
        return data_keys();
      },
      children: (key, count) => ssr(_tmpl$5, ssrHydrationKey(), `border-2 border-black whitespace-nowrap text-sm font-medium text-gray-900 ${count() === 0 ? "font-medium text-left" : "font-light text-center"}`, props.col_conditions && props.col_conditions[key] ? escape(props.col_conditions[key](key, record[key])) : escape(record[key]))
    })))
  })));
}

__astro_tag_component__(Table, "@astrojs/solid-js");

const _tmpl$ = ["<span", " class=\"", "\">", "</span>"],
  _tmpl$2 = ["<h3", " class=\"text-xl font-bold\">Trabajador</h3>"],
  _tmpl$3 = ["<div", " class=\"w-full max-w-[800px] h-screen flex flex-col items-center gap-5\"><h1 class=\"uppercase tracking-wide font-bold underline\">Jos\xE9 Salcedo Nu\xF1ez</h1><div class=\"flex justify-around uppercase w-full max-w-7xl\"><h2>N\xF3mina periodo <!--#-->", "<!--/--></h2><h2>", "</h2><h2 class=\"font-bold underline\">", "</h2></div><!--#-->", "<!--/--><div class=\"text-xs w-full\"><h3 class=\"font-bold uppercase\">Trabajadores: <!--#-->", "<!--/--></h3><h3 class=\"font-bold uppercase underline\">Clave</h3><ul class=\"ml-5\"><li>A = ASISTENCIA</li><li>B = BAJA</li><li>P = PERMISO (FALTA INJUSTIFICADA, NO AMERITA ACTA ADMINISTRATIVA)</li><li>F = FALTA INJUSTIFICADA (AMERITA ACTA ADMINISTRATIVA)</li><li>V = VACACIONES</li><li>N = NO LABORABLE</li><li>I = INCAPACIDAD</li></ul></div><div class=\"w-full flex flex-col items-center mt-20\"><div class=\"w-1/4 h-[4px] bg-black\"></div><p>JEFE DE PRODUCCI\xD3N</p></div></div>"];
const today = /* @__PURE__ */new Date();
const year_start = new Date(today.getFullYear(), 0, 1);
const week_num = Math.ceil(Math.floor((today - year_start) / (24 * 60 * 60 * 1e3)) / 7);
const weekday_today = today.getDay();
const last_thursday = /* @__PURE__ */new Date();
const next_wednesday = /* @__PURE__ */new Date();
last_thursday.setDate(weekday_today < 4 ? today.getDate() - weekday_today - 3 : today.getDate() - weekday_today + 4);
next_wednesday.setDate(weekday_today < 4 ? today.getDate() - weekday_today + 3 : today.getDate() - weekday_today + 10);
const fechas = fillDates(last_thursday, next_wednesday);
const INCIDENCIAS = {
  "A": "bg-green-50 text-green-600",
  "B": "bg-gray-50 text-gray-600",
  "P": "bg-green-50 text-green-600",
  "F": "bg-red-50 text-red-600",
  "V": "bg-gray-50 text-gray-600",
  "N": "bg-gray-50 text-gray-600",
  "I": "bg-yellow-50 text-yellow-600"
};
function fillDates(start, finish) {
  let dates = [];
  let i_date = new Date(start.getTime());
  for (let date = i_date; date <= finish; date.setDate(date.getDate() + 1)) {
    const utc_str_arr = date.toUTCString().split(" ");
    dates.push(`${utc_str_arr[1]} ${utc_str_arr[2]}`);
  }
  return dates;
}
function fillReport(fechas2, incidencias, trabajadores) {
  const table = new Array(trabajadores.length);
  const date_diff = today.getDate() - last_thursday.getDate() + 1;
  const date_dict = {
    0: "J",
    1: "V",
    2: "S",
    3: "D",
    4: "L",
    5: "M",
    6: "m"
  };
  for (let i = 0; i < trabajadores.length; i++) {
    table[i] = {
      nombres: `${trabajadores[i].Nombres} ${trabajadores[i].APaterno}`.toUpperCase()
    };
    for (let j = 0; j < date_diff; j++) {
      table[i][date_dict[j]] = "A";
    }
  }
  for (let i = 0; i < incidencias.length; i++) {
    const incidencia = incidencias[i];
    const date = new Date(incidencia.Fecha);
    const utc_str_arr = date.toUTCString().split(" ");
    const fecha_str = `${utc_str_arr[1]} ${utc_str_arr[2]}`;
    const id_fecha = fechas2.indexOf(fecha_str);
    let id_trab;
    let j = 0;
    while (j < trabajadores.length) {
      if (trabajadores[j].idTrabajador === incidencia.idTrabajador) {
        id_trab = j;
        break;
      }
      j++;
    }
    table[id_trab][date_dict[id_fecha]] = incidencia.idIncidencia;
  }
  return table;
}
function make_report(trabajadores, incidencias) {
  const trab_obj = reestructure_obj(trabajadores);
  const incidencias_obj = reestructure_obj(incidencias);
  sort_obj_array(trab_obj, "idNivel", false);
  return fillReport(fechas, incidencias_obj, trab_obj);
}
function incid_type(key, value) {
  if (key === "nombres" || !INCIDENCIAS[value]) return value;
  return ssr(_tmpl$, ssrHydrationKey(), `inline-flex w-full h-full font-bold justify-center items-center text-lg ${escape(INCIDENCIAS[value], true)}`, escape(value));
}
const col_conditions = {
  J: incid_type,
  V: incid_type,
  S: incid_type,
  D: incid_type,
  L: incid_type,
  M: incid_type,
  m: incid_type
};
function ReporteASistencia() {
  const [table, setTable] = createSignal(null);
  const [state, setState] = createSignal({
    state: "LOADING"
  });
  const [trab_resource] = createResource(fetchTrabajadores);
  const [incid_resource] = createResource(fetchIncidencias);
  const days = {
    0: "J",
    1: "V",
    2: "S",
    3: "D",
    4: "L",
    5: "M",
    6: "m"
  };
  const months = {
    0: "ENERO",
    1: "FEBRERO",
    2: "MARZO",
    3: "ABRIL",
    4: "MAYO",
    5: "JUNIO",
    6: "JULIO",
    7: "AGOSTO",
    8: "SEPTIEMBRE",
    9: "OCTUBRE",
    10: "NOVIEMBRE",
    11: "DICIEMBRE"
  };
  let titles = {
    0: ssr(_tmpl$2, ssrHydrationKey())
  };
  for (let i = 0; i < 7; i++) {
    titles[i + 1] = `${days[i]} - ${fechas[i].split(" ")[0]}`;
  }
  createEffect(async () => {
    if (trab_resource.state === "ready" && incid_resource.state === "ready") {
      setState({
        state: "READY",
        msg: ""
      });
      const report = make_report(trab_resource.latest, incid_resource.latest);
      setTable(report);
    } else if (trab_resource.error || incid_resource.error) {
      setState({
        state: "ERROR",
        msg: "Error de peticion de tablas"
      });
    } else if (trab_resource.loading || incid_resource.loading) {
      setState({
        state: "LOADING",
        msg: "Cargando informacion..."
      });
    }
  });
  return createComponent(Switch, {
    get children() {
      return [createComponent(Match, {
        get when() {
          return state().state === "ERROR";
        },
        get children() {
          return state().msg;
        }
      }), createComponent(Match, {
        get when() {
          return state().state === "LOADING";
        },
        get children() {
          return state().msg;
        }
      }), createComponent(Match, {
        get when() {
          return state().state === "READY" && table() !== null && typeof table()?.length !== "undefined";
        },
        get children() {
          return ssr(_tmpl$3, ssrHydrationKey(), escape(week_num), escape(months[today.getMonth()]), escape(today.getFullYear()), escape(createComponent(Table, {
            get data() {
              return table();
            },
            get titles() {
              return Object.values(titles);
            },
            col_conditions: col_conditions
          })), escape(table().length));
        }
      })];
    }
  });
}

__astro_tag_component__(ReporteASistencia, "@astrojs/solid-js");

const $$Astro$1 = createAstro("https://thp.dev");
const $$Layout = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Layout;
  const { title } = Astro2.props;
  return renderTemplate`<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="description" content="Astro description">
		<meta name="viewport" content="width=device-width">
		<link rel="icon" type="image/svg+xml" href="/favicon.svg">
		<meta name="generator"${addAttribute(Astro2.generator, "content")}>
		<title>${title}</title>
	${renderHead($$result)}</head>
	<body>
		${renderSlot($$result, $$slots["default"])}
	</body></html>`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/layouts/Layout.astro");

const $$Astro = createAstro("https://thp.dev");
const $$Index = createComponent$1(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Index;
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "Welcome to Astro." }, { "default": ($$result2) => renderTemplate`
	${renderComponent($$result2, "ReporteAsistencia", ReporteASistencia, { "client:load": true, "client:component-hydration": "load", "client:component-path": "C:/Users/pepoc/Documents/Trabajo/thp/app/src/components/ReporteAsistencia", "client:component-export": "default" })}
` })}`;
}, "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro");

const $$file = "C:/Users/pepoc/Documents/Trabajo/thp/app/src/pages/index.astro";
const $$url = "";

const index = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$Index,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

export { $$Layout as $, Table as T, index as i };
